package com.example.myreportaftertravel



import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.helper.ItemTouchHelper
import android.support.v7.widget.helper.ItemTouchHelper.DOWN
import android.support.v7.widget.helper.ItemTouchHelper.UP
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    var data:ArrayList<MyCafe> = ArrayList()
    lateinit var adapter:MyCafeAdapter
    var wifi = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }
    fun init(){
        initLayout()
        initSwipe()
        readFile()
        rcClick()
    }
    fun rcClick(){
        listView.setOnClickListener {

        }
    }

    fun initSwipe(){
        val simpleItemTouchCallBack = object: ItemTouchHelper.SimpleCallback(UP or DOWN, ItemTouchHelper.RIGHT){
            override fun onMove(p0: RecyclerView, p1: RecyclerView.ViewHolder, p2: RecyclerView.ViewHolder): Boolean {
                //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                adapter.moveItem(p1.adapterPosition, p2.adapterPosition)
                return true
            }

            override fun onSwiped(p0: RecyclerView.ViewHolder, p1: Int) {
                //TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                adapter.removeItem(p0.adapterPosition)
            }
        }   //객체 생성
        val itemTouchHelper = ItemTouchHelper(simpleItemTouchCallBack)
        itemTouchHelper.attachToRecyclerView(listView)
    }
    fun initLayout(){
        val layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        //val layoutManager = GridLayoutManager(this, 3)
        //val layoutManager = StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.GAP_HANDLING_NONE)
        listView.layoutManager = layoutManager
        adapter = MyCafeAdapter(data)
        listView.adapter = adapter
        save.setOnClickListener {
            var point_country = -1;
            when(country.text.toString()){
                "태국"->{
                    for(i in data){
                        if(i.country == "태국")
                            point_country = i.hashCode()
                    }
                }
                "미국"->{
                    for(i in data){
                        if(i.country == "미국")
                            point_country = i.hashCode()
                    }
                }
            }
            adapter.moveItem(0, point_country)
        }
    }

    fun readFile(){ //words, array 초기화
        var scan = Scanner(resources.openRawResource(R.raw.test_text))
        while(scan.hasNextLine()){
            val str = scan.nextLine()
            val str_result = str.split(',')
            data.add(0, MyCafe(str_result[0], str_result[5], str_result[1]))
        }
        scan.close()
    }
}
