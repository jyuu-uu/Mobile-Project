package com.example.myreportaftertravel

data class MyCafe (var country:String, var point:String, var weather:String){
}